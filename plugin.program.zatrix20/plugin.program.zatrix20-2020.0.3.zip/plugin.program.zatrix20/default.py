#-*- coding: utf-8 -*-
import xbmc, xbmcaddon, xbmcgui, xbmcplugin,os,sys
import shutil
import urllib2,urllib
import re
import extract
import time
import downloader
import plugintools
import zipfile
import ntpath
import base64
import cookielib
import auth

databasePath = xbmc.translatePath('special://database')
DBPATH = xbmc.translatePath('special://database')
TNPATH = xbmc.translatePath('special://thumbnails');
thumbnailPath = xbmc.translatePath('special://thumbnails');
thumbdir = xbmc.translatePath('special://thumbnails')
tempPath = xbmc.translatePath('special://temp')
USER_AGENT = 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3'
base='http://www.none.com'
ADDON=xbmcaddon.Addon(id='plugin.program.zatrix20')
dialog = xbmcgui.Dialog()
VERSION = "1.0.0"
PATH = "afkbox"


def index():
	addDir('Zatrix Update','',2,'http://addons.allefilmskijken.com/images/update.png','http://addons.allefilmskijken.com/images/achtergrond.png','')
	addDir('Zatrix Extra','',3,'http://addons.allefilmskijken.com/images/update.png','http://addons.allefilmskijken.com/images/achtergrond.png','')
	setView('movies', 'MAIN')

def get_params():
		param=[]
		paramstring=sys.argv[2]
		if len(paramstring)>=2:
				params=sys.argv[2]
				cleanedparams=params.replace('?','')
				if (params[len(params)-1]=='/'):
						params=params[0:len(params)-2]
				pairsofparams=cleanedparams.split('&')
				param={}
				for i in range(len(pairsofparams)):
						splitparams={}
						splitparams=pairsofparams[i].split('=')
						if (len(splitparams))==2:
								param[splitparams[0]]=splitparams[1]

		return param

params=get_params()
url=None
name=None
mode=None
iconimage=None
fanart=None
description=None

try:
		url=urllib.unquote_plus(params["url"])
except:
		pass
try:
		name=urllib.unquote_plus(params["name"])
except:
		pass
try:
		iconimage=urllib.unquote_plus(params["iconimage"])
except:
		pass
try:
		mode=int(params["mode"])
except:
		pass
try:
		fanart=urllib.unquote_plus(params["fanart"])
except:
		pass
try:
		description=urllib.unquote_plus(params["description"])
except:
		pass

print str(PATH)+': '+str(VERSION)
print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)
print "IconImage: "+str(iconimage)

def setView(content, viewType):
	# set content type so library shows more views and info
	if content:
		xbmcplugin.setContent(int(sys.argv[1]), content)
	if ADDON.getSetting('auto-view')=='true':
		xbmc.executebuiltin("Container.SetViewMode(%s)" % ADDON.getSetting(viewType) )

if mode==None:
	index()

elif mode==1:
	auth.wizard(name,url,description)

elif mode==2:
	auth.update()

elif mode==3:
	auth.extra()

elif mode==4:
	auth.wizardrem(name,url,description)

xbmcplugin.endOfDirectory(int(sys.argv[1]))