import xbmc
import xbmcgui
import xbmcaddon
import os
import shutil
from libs import kodi

Addon = xbmcaddon.Addon()
addon_id = Addon.getAddonInfo('id')
settings = xbmcaddon.Addon(id=addon_id)

ACTION_LEFT = 1  # Left arrow key
ACTION_RIGHT = 2  # Right arrow key
ACTION_UP = 3  # Up arrow key
ACTION_DOWN = 4  # Down arrow key
ACTION_PAGE_UP = 5
ACTION_PAGE_DOWN = 6
ACTION_SELECT_ITEM = 7
ACTION_PARENT_DIR = 9
ACTION_PREVIOUS_MENU = 10  # ESC action
ACTION_SHOW_INFO = 11
ACTION_NEXT_ITEM = 14
ACTION_PREV_ITEM = 15
ACTION_BACKSPACE = 110
ACTION_CONTEXT_MENU = 117

ACTION_MOUSE_WHEEL_UP = 104  # Mouse wheel up
ACTION_MOUSE_WHEEL_DOWN = 105  # Mouse wheel down
ACTION_MOUSE_DRAG = 106  # Mouse drag
ACTION_MOUSE_MOVE = 107  # Mouse move

KEY_NAV_BACK = 92
KEY_HOME = 159
KEY_ESC = 61467


class PopupNote(xbmcgui.WindowXMLDialog):
	contents = ''
	note = 4001
	rdpage = 4002
	traktpage = 4003
	vpnpage = 4004
	infopage = 4005
	afspage = 4006
	rdsetting = 4020
	trakt = 4021
	vpn = 4022
	remind_later = 4023
	dismiss = 4024

	def __init__(self, xml_name, addons_path, skin_folder):
		super(PopupNote, self).__init__()  # (self, xml_name, addons_path, skin_folder)
		self.page_up = 5
		self.page_down = 6
		self.previous_menu = 10
		self.back = 92
		self.buttonClicked = None

		# XML id's
		self.title_box_control = 20301
		self.content_box_control = 20302

	def onInit(self):
		self.contents = settings.getSetting("noteMessage")
		title_box = self.getControl(self.title_box_control)
		title_box.setText("[B][COLOR lime]Unofficial Kodi Community Updates[/COLOR][/B]")
		content_box = self.getControl(self.content_box_control)
		content_box.setText(self.contents)

	def onAction(self, action):
		if action in (self.previous_menu, self.back):
			settings.setSetting("noteType", '')
			settings.setSetting("noteImage", '')
			settings.setSetting("noteMessage", '')
			self.close()

	def onClick(self, control_id):
		if control_id == self.remind_later:
			settings.setSetting("noteType", '')
			settings.setSetting("noteImage", '')
			settings.setSetting("noteMessage", '')
			self.close()

		elif control_id == self.dismiss:
			dialog = xbmcgui.Dialog().yesno("Afmelden","Hiermee meld u zich af bij dit notificatie scherm en opent niet opnieuw na herstart.\nOm dit scherm te heropenen ga dan naar [COLOR darkturquoise]updaten[/COLOR] -> [COLOR darkturquoise]notificatiescherm openen[/COLOR].\n[COLOR gray][I](Notificatiescherm opent pas weer automatich als er een wijziging is doorgevoerd)[/I][/COLOR]\n\nWeet u dit zeker dat u dit wilt uitvoeren?")
			if dialog:
				self.close()
			else:
				pass

		elif control_id == 4007:
			xbmcgui.Dialog().ok('', str(control_id))

		elif control_id == self.rdsetting:
			dialog = xbmcgui.Dialog().yesno("Real Debrid Authoriseren","Hiermee meld u zich af bij dit notificatie scherm en opent niet opnieuw na herstart.\nOm dit scherm te heropenen ga dan naar [COLOR darkturquoise]updaten[/COLOR] -> [COLOR darkturquoise]notificatiescherm openen[/COLOR].\n[COLOR gray][I](Notificatiescherm opent pas weer automatich als er een wijziging is doorgevoerd)[/I][/COLOR]\n\nWeet u dit zeker dat u dit wilt uitvoeren?")
			if dialog:
				self.close()
				xbmc.executebuiltin("ActivateWindow(Skinsettings)")
				xbmc.sleep(1000)
				xbmc.executebuiltin('Control.SetFocus(9007)')
			else:
				pass

		elif control_id == self.trakt:
			dialog = xbmcgui.Dialog().yesno("Trakt Koppelen","Hiermee meld u zich af bij dit notificatie scherm en opent niet opnieuw na herstart.\nOm dit scherm te heropenen ga dan naar [COLOR darkturquoise]updaten[/COLOR] -> [COLOR darkturquoise]notificatiescherm openen[/COLOR].\n[COLOR gray][I](Notificatiescherm opent pas weer automatich als er een wijziging is doorgevoerd)[/I][/COLOR]\n\nWeet u dit zeker dat u dit wilt uitvoeren?")
			if dialog:
				self.close()
				xbmc.executebuiltin("ActivateWindow(Skinsettings)")
				xbmc.sleep(1000)
				xbmc.executebuiltin('Control.SetFocus(9006)')
			else:
				pass

		elif control_id == self.vpn:
			dialog = xbmcgui.Dialog().yesno("VPN Instellen","Hiermee meld u zich af bij dit notificatie scherm en opent niet opnieuw na herstart.\nOm dit scherm te heropenen ga dan naar [COLOR darkturquoise]updaten[/COLOR] -> [COLOR darkturquoise]notificatiescherm openen[/COLOR].\n[COLOR gray][I](Notificatiescherm opent pas weer automatich als er een wijziging is doorgevoerd)[/I][/COLOR]\n\nWeet u dit zeker dat u dit wilt uitvoeren?")
			if dialog:
				self.close()
				xbmc.executebuiltin("ActivateWindow(Skinsettings)")
				xbmc.sleep(1000)
				xbmc.executebuiltin('Control.SetFocus(9003)')
			else:
				pass

	def onFocus(self, control_id):
		if control_id == self.note:
			title_box = self.getControl(self.title_box_control)
			title_box.setText("[B]Welkom bij de Zatrix Build[/B]")
			content_box = self.getControl(self.content_box_control)
			content_box.setText(self.contents)

		elif control_id == self.rdpage:
			title_box = self.getControl(self.title_box_control)
			title_box.setText("[B]Real Debrid Info[/B]")
			contents = '\nReal Debrid is vandaag de dag een must-have voor iedere streamer.\nMeeste gratis providers zijn niet meer zoals het geweest was enkele jaren terug.\n[I](het werkt nog wel maar wil je echt alles uit de build halen is het een must-have)[/I]\n\n[B]Wat is Real Debrid[/B]\n\nReal Debrid is een vrij goede en goedkope payserver en hiermee de beste streams beschikbaar stelt. En zijn deze streams voorzien van DTS en 1080HD+ kwaliteit.\nVoor 3,- kun je 15 dagen onbeperkt genieten van de beste streams die Real debrid te bieden heeft, dus handig om te testen. Ben je tevreden?\nNeem dan een langere periode, voor bijvoorbeeld 180 dagen betaal je maar 16 euro, dus is omgerekend maar 2,70 per maand.\nReal Debrid verlengt niet automatisch je account dus je zit nergens aan vast.\n\n[B]Meer info: [COLOR darkturquoise]HTTP://BIT.LY/RD-INFO[/COLOR][/B]'
			content_box = self.getControl(self.content_box_control)
			content_box.setText(contents)

		elif control_id == self.traktpage:
			title_box = self.getControl(self.title_box_control)
			title_box.setText("[B]Trakt Info[/B]")
			contents = '\nOm bij te houden wat je nu allemaal bekeken hebt is Trakt een van de beste features die je daarvoor kunt gebruiken.\nDirect na bekijken van een film of serie wordt deze afgevinkt in het Trakt account.\n\n[B]Wat is Trakt[/B]\n\n[COLOR darkorange]Trakt.tv[/COLOR] houd bij wat je kijkt en wat je zou willen gaan kijken maar ook wat je nu gekeken hebt en waar je gebleven was.\nNaast het registeren van wat je kijkt geeft het platform je ook advies op basis van je kijkgedrag. Trakt is geheel gratis en via verschillende apps bij te houden.\nHet handige van het gebruik van Trakt is dat je account op meerdere mediaspelers te gebruiken is en bij een eventuele herinstallatie van je mediaspeler heb je al de bekeken inhoud weer terug afgevinkt.\n\n[B]Meer info: [COLOR darkturquoise]HTTP://BIT.LY/TRAKT-INFO[/COLOR][/B]'
			content_box = self.getControl(self.content_box_control)
			content_box.setText(contents)

		elif control_id == self.vpnpage:
			title_box = self.getControl(self.title_box_control)
			title_box.setText("[B]VPN Info[/B]")
			contents = '\nSteeds meer mensen gebruiken een VPN. VPN staat voor Virtual Private Network.\nEen VPN-verbinding is een gemakkelijke en efficinte manier om je online veiligheid, privacy en vrijheid te verbeteren.\n\n[B]Wat is een VPN[/B]\n\nEen VPN is een veilige verbinding tussen je medispeler en het internet.\nAls je het internet op gaat, doe je dit met een uniek IP-adres. Het IP-adres is als het ware de persoonlijke identificatiecode van jouw internetverbinding.\nHet staat op naam en adres van de persoon die de internetprovider betaalt. Zo ben je online herkenbaar en te traceren bij alles wat je doet - maar niet, als je een VPN gebruikt! Een VPN bied je in de meeste gevallen meer dan voldoende bescherming.\nGebruik je [COLOR darkorange]Real Debrid[/COLOR] dan is het niet persee nodig om een VPN te nemen maar geeft je wel meer anonimiteit.\n\n[B]Meer info: [COLOR darkturquoise]HTTP://BIT.LY/VPN-INFO[/COLOR][/B]'
			content_box = self.getControl(self.content_box_control)
			content_box.setText(contents)

		elif control_id == self.infopage:
			title_box = self.getControl(self.title_box_control)
			title_box.setText("[B]Info[/B]")
			contents = '\nTeam Zatrix is niet verantwoordelijk voor de aangeboden content en ontwikkeling van de addons. Addons worden vrij op internet aangeboden en toegevoegd aan de build, meeste addons zoeken het web af naar content en zijn niet de aanbieder. Gebruik van deze addons is voor eigen risico\n\n[B]Support & handige links[/B]\n\n[COLOR darkturquoise]Facebook support pagina[/COLOR]: HTTP://BIT.LY/JOINZATRIX\n\n[COLOR grey]AlleFilmsKijken Tips paginas[/COLOR]\n\n[COLOR darkturquoise]Real Debrid[/COLOR]: HTTP://BIT.LY/RD-INFO\n[COLOR darkturquoise]Trakt[/COLOR]: HTTP://BIT.LY/TRAKT-INFO\n[COLOR darkturquoise]VPN[/COLOR]: HTTP://BIT.LY/VPN-INFO\n[COLOR darkturquoise]Alle Tips/Info[/COLOR]: HTTP://BIT.LY/AFKTIPS'
			content_box = self.getControl(self.content_box_control)
			content_box.setText(contents)

		elif control_id == self.afspage:
			title_box = self.getControl(self.title_box_control)
			title_box.setText("[B]Afsluiten Notificatiescherm[/B]")
			contents = '\n\n[B]Herinneren[/B]\n\nWilt u dit scherm bij de volgende opstart van uw mediaspeler nogmaals zien? klik dan op de optie herinneren.\n\n[B]Afmelden[/B]\n\nWilt u dit scherm niet meer zien na het opstarten van uw mediaspeler? klik dan op de optie afmelden.'
			content_box = self.getControl(self.content_box_control)
			content_box.setText(contents)

		elif control_id == 4007:
			xbmcgui.Dialog().ok('', str(control_id))


def art(f, fe=''):
	fe1 = ('.png', '.jpg', '.gif', '.wav', '.txt')
	for ext in fe1:
		if ext in f:
			f = f.replace(ext, '')
			fe = ext
			break
	return xbmc.translatePath(addon_path(f + fe))


def artp(f, fe='.png'):
	return art(f, fe)


def artj(f, fe='.jpg'):
	return art(f, fe)


def addon_path(f, fe=''):
	path = settings.getAddonInfo('path')
	return xbmc.translatePath(os.path.join(path, f + fe))


def check_news2(message_type, override_service=False):
	# debob(["notifications-on-startup", settings.getSetting("notifications-on-startup"), "override_service ",
	#        override_service])
	if (settings.getSetting("notifications-on-startup") == 'false') or override_service:
		info_location = "https://raw.githubusercontent.com/iamAngel/ZTpatch/master/news.txt"
		info_location2 = addon_path("test.txt")
		info_location3 = addon_path("url.txt")
		try:
			if os.path.isfile(info_location2):
				with open(info_location2, 'rb') as temp_file:
					html = temp_file.read()
			elif os.path.isfile(info_location3):
				with open(info_location3, 'rb') as temp_file:
					html = kodi.read_file(temp_file.read().strip()) if temp_file.read() else ''
			else:
				# html = open_url(info_location)
				html = kodi.read_file(info_location)
		except IOError:
			html = ''
		new_image = html.split('|||')[0].strip() if '|||' in html else ''
		new_message = html.split('|||')[1].strip() if '|||' in html else html
		old_note_image = settings.getSetting("noteImage")
		old_note_message = settings.getSetting("noteMessage")
		old_note_image = old_note_image.replace(artp('blank1'), '')
		new_note = ((len(new_image) > 0) or (len(new_message) > 0))
		old_note = (len(old_note_image) > 0 or len(old_note_message) > 0)
		if ((old_note and (not new_note or (old_note_image == new_image or old_note_message == new_message)))
				or (not old_note and not new_note)) and not override_service:
			return
		if new_note and (not old_note_image == new_image) or (not old_note_message == new_message):
			settings.setSetting("noteType", message_type)
			settings.setSetting("noteImage", new_image)
			settings.setSetting("noteMessage", new_message)
		win = PopupNote('note-skin.xml', Addon.getAddonInfo('path'), 'notification')
		win.doModal()
		del win
