import xbmc,xbmcaddon,xbmc,string,logging,array
from libs import kodi
Addon = xbmcaddon.Addon()
addon_id = Addon.getAddonInfo('id')
settings = xbmcaddon.Addon(id=addon_id)
## ################################################## ##
## ################################################## ##
## Start of program
import notification
if kodi.get_setting('notifications-on-startup') == "false":
    notification.check_news2("t")
else:
    pass
## ################################################## ##
## ################################################## ##