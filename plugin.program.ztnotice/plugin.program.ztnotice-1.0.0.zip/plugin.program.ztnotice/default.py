import os,sys,xbmc,xbmcplugin,xbmcaddon,xbmcgui,urllib,urllib2,re,time,datetime,string,StringIO,logging,random,array,htmllib,xbmcvfs
import notification
notification.check_news2("t", override_service=True)
## ################################################## ##
## ################################################## ##