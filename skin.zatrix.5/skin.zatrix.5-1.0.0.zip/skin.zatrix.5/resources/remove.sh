#!/bin/sh
#kodi-send -a "Notification(script.sh:,'$1')"
#kodi-send -a "ReloadSkin()"

myInfo(){
  TIME=3000
  if [[ "$#" == 2 ]]; then
	TIME=$(($2*1000))
  fi

  kodi-send -a "Notification(Verwijderen vpn bestanden:,$1,$TIME )" &> /dev/null
  echo $1
}


if [[ "$1" == "vpn" ]]; then
	rm -rf '/storage/.kodi/addons/service.vpn.manager'
	rm -rf '/storage/.kodi/addons/repository.zomboided.plugins'
	rm -rf '/storage/.kodi/addon_data/service.vpn.manager'
fi