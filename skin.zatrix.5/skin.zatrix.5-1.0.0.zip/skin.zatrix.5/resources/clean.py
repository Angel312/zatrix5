############################################################################
#
#  Copyright 2015 AFK-Box
#
############################################################################


import xbmc, xbmcgui
import shutil
import os


thumbnailPath = xbmc.translatePath('special://thumbnails');
databasePath = xbmc.translatePath('special://database')

class MyClass(xbmcgui.Window):
  def __init__(self):
    if os.path.exists(thumbnailPath)==True:
            dialog = xbmcgui.Dialog()
            if dialog.yesno("Thumbnails verwijderen", "Deze optie zal alle thumbnails verwijderen van uw systeem", "Bent u er zeker van dat u dat wilt?"):
                for root, dirs, files in os.walk(thumbnailPath):
                    file_count = 0
                    file_count += len(files)
                    if file_count > 0:
                        for f in files:
                            try:
                                os.unlink(os.path.join(root, f))
                            except:
                                pass
    else:
        pass

    text13 = os.path.join(databasePath,"Textures13.db")
    os.unlink(text13)

    dialog.ok("AFK-Box herstarten", "Herstart uw AFK-Box om de thumbnail database opnieuw op te bouwen")
    xbmc.executebuiltin('Reboot')

mydisplay = MyClass()
del mydisplay