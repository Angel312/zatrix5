import xbmcgui
import xbmc
import os
import shutil

xbmc.executebuiltin('RunAddon(service.coreelec.settings)')
xbmc.sleep(1500)
xbmc.executebuiltin('Control.SetFocus(1000,3)')
xbmc.sleep(500)
xbmc.executebuiltin('Control.SetFocus(1200,0)')