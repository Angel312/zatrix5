import xbmcgui
import xbmc
import os
import shutil

if xbmc.getCondVisibility("System.HasAddon(service.libreelec.settings)") or xbmc.getCondVisibility("System.HasAddon(service.coreelec.settings)"):
        if xbmc.getCondVisibility("System.HasAddon(service.libreelec.settings)"):
            xbmc.executebuiltin('RunAddon(service.openelec.settings)')
        elif xbmc.getCondVisibility("System.HasAddon(service.coreelec.settings)"):
            xbmc.executebuiltin('RunAddon(service.libreelec.settings)')
        xbmc.sleep(1500)
        xbmc.executebuiltin('Control.SetFocus(1000,2)')
        xbmc.sleep(500)
        xbmc.executebuiltin('Control.SetFocus(1200,0)')