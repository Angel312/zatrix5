import xbmc, xbmcgui
import shutil
import urllib2,urllib
import time
import os

os.remove('/storage/.config/remote.conf')
os.system("su -c 'reboot'")