import xbmc, xbmcgui
import shutil
import urllib2,urllib
import time
import os

bashCommand = "/bin/bash /storage/.kodi/addons/skin.zatrix.5/resources/remove.sh "+sys.argv[1]
os.system(bashCommand)
xbmc.executebuiltin("ActivateWindow(busydialog)")
time.sleep(10)
xbmc.executebuiltin("Dialog.Close(busydialog)")