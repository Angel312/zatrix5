import xbmcgui
import xbmc
import os
import shutil
import time
import errno

newpath = r'/storage/.restore'
if not os.path.exists(newpath):
    os.makedirs(newpath)

dialog = xbmcgui.Dialog().yesno("Herinstalleren","","De Mediaspeler wordt opnieuw geinstalleerd","Weet u dit zeker dat u dit wilt uitvoeren?")

if dialog:
    shutil.copy2('/storage/backup/BackupAFKb0x11.tar', '/storage/.restore')
    xbmc.executebuiltin("ActivateWindow(busydialog)")
    time.sleep(10)
    xbmc.executebuiltin("Dialog.Close(busydialog)")
    xbmc.executebuiltin('Reboot')
else:
    xbmc.executebuiltin("ActivateWindow(return)")