import xbmcgui
import xbmc
import os
import shutil
import time

dialog = xbmcgui.Dialog().yesno("Handmatig controleren op Addon updates","","Alle addons bijwerken naar laatst beschikbare versie","Weet u dit zeker dat u dit wilt uitvoeren?")

if dialog:
    xbmc.executebuiltin("UpdateAddonRepos")
    xbmc.executebuiltin("UpdateLocalAddons")
    xbmc.executebuiltin("ActivateWindow(busydialognocancel)")
    time.sleep(10)
    xbmc.executebuiltin("Dialog.Close(busydialognocancel)")
else:
    xbmc.executebuiltin("ActivateWindow(return)")