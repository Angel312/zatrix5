import xbmcgui
import xbmc
import os
import shutil
import time

dialog = xbmcgui.Dialog().yesno("Verwijderen VPN","","VPN Manager verwijderen incl alle instellingen","Weet u dit zeker dat u dit wilt uitvoeren?")

if dialog:
    xbmc.executebuiltin("RunScript(special://skin/resources/remove.py,vpn)")
    xbmc.executebuiltin("ActivateWindow(busydialognocancel)")
    time.sleep(10)
    xbmc.executebuiltin("Dialog.Close(busydialognocancel)")
    xbmc.executebuiltin('RestartApp')
else:
    pass